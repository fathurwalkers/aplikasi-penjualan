<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('datatables')); ?>/datatables.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('header-content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-md-6 col-lg-6">
                <h5 class="my-auto text-dark">Kelola Users - Daftar Users</h5>
            </div>
            <div class="col-sm-6 col-md-6 col-lg-6">

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="card mb-3">
        <div class="card-body">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-6 col-lg-6">
                        <h5 class="my-auto text-dark">Daftar User</h5>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-6 ml-auto">
                        <button type="button" class="btn btn-md btn-primary d-flex my-auto ml-auto" data-toggle="modal"
                            data-target="#modaltambah">
                            Tambah User
                        </button>
                    </div>
                </div>

                <!-- Modal Tambah -->
                <div class="modal fade" id="modaltambah" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Hapus Produk</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form action="<?php echo e(route('post-register')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <p class="text-dark">
                                        Silahkan mengisikan data user yang akan ditambah.
                                    </p>

                                    <div class="form-group">
                                        <label for="role">Nama Lengkap</label>
                                        <select class="form-control" id="role" name="role">
                                            <option value="admin">Admin</option>
                                            <option value="user">Staff</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="login_nama">Nama Lengkap</label>
                                        <input name="login_nama" id="login_nama" type="text" class="form-control"
                                            value="<?php echo e(old('login_nama')); ?>" autofocus required>
                                    </div>
                                    <div class="form-group">
                                        <label for="login_email">Email</label>
                                        <input name="login_email" id="login_email" type="email"
                                            value="<?php echo e(old('login_email')); ?>" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="login_telepon">No. Telepon / HP</label>
                                        <input name="login_telepon" id="login_telepon" type="text" class="form-control"
                                            value="<?php echo e(old('login_telepon')); ?>" required>
                                    </div>

                                    <hr />

                                    <div class="form-group">
                                        <label for="login_username">Username</label>
                                        <input name="login_username" id="login_username" type="text" class="form-control"
                                            value="<?php echo e(old('login_username')); ?>" autofocus required>
                                    </div>
                                    <div class="form-group">
                                        <label for="login_password">Password</label>
                                        <input name="login_password" id="login_password" type="password"
                                            class="form-control" required>
                                    </div>

                                    <div class="form-group">
                                        <label for="login_password2">Konfirmasi Password</label>
                                        <input name="login_password2" id="login_password2" type="password"
                                            class="form-control" required>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batalkan</button>
                                    <button type="submit" class="btn btn-danger">Tambah Data</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- END Modal Tambah -->

                <hr />
                <div class="row">
                    <div class="table-responsive">
                        <table id="example" class="display table-bordered" style="width:100%">
                            <thead class="thead-dark">
                                <tr>
                                    <th>No.</th>
                                    <th>Nama</th>
                                    <th>Username</th>
                                    <th>Email</th>
                                    <th>No. HP / Telepon</th>
                                    <th>Role</th>
                                    <th>Kelola</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $all_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center text-dark"><?php echo e($loop->iteration); ?></td>
                                        <td class="text-center text-dark"><?php echo e($item->login_nama); ?></td>
                                        <td class="text-center text-dark"><?php echo e($item->login_username); ?></td>
                                        <td class="text-center text-dark"><?php echo e($item->login_email); ?></td>
                                        <td class="text-center text-dark"><?php echo e($item->login_telepon); ?></td>
                                        <td class="text-center text-dark">
                                            <?php switch($item->login_level):
                                                case ('admin'): ?>
                                                    <button type="button"
                                                        class="badge badge-sm badge-warning btn-outline-warning">
                                                        ADMIN
                                                    </button>
                                                <?php break; ?>

                                                <?php case ('user'): ?>
                                                    <button type="button" class="badge badge-sm badge-info btn-outline-info">
                                                        STAFF
                                                    </button>
                                                <?php break; ?>
                                            <?php endswitch; ?>
                                        </td>
                                        <td class="text-center text-dark">
                                            <button class="btn btn-sm btn-info mr-1" type="button" data-toggle="modal"
                                                data-target="#modalubah<?php echo e($item->id); ?>">
                                                Ubah
                                            </button>
                                            <button class="btn btn-sm btn-danger mr-1" type="button" data-toggle="modal"
                                                data-target="#modalhapus<?php echo e($item->id); ?>">
                                                Hapus
                                            </button>
                                        </td>
                                    </tr>


                                    <!-- Modal Ubah -->
                                    <div class="modal fade" id="modalubah<?php echo e($item->id); ?>" tabindex="-1"
                                        role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Hapus Produk</h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <form action="<?php echo e(route('update-user', $item->id)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-body">
                                                        <p class="text-dark">
                                                            Silahkan mengisikan data user yang akan diubah.
                                                        </p>

                                                        <div class="row">
                                                            <div class="col-sm-6 col-md-6 col-lg-6">
                                                                <div class="form-group">
                                                                    <label for="login_nama">
                                                                        <h6>Nama User</h6>
                                                                    </label>
                                                                    <input type="text" class="form-control"
                                                                        id="login_nama"
                                                                        placeholder="Masukkan nama produk baru..."
                                                                        name="login_nama"
                                                                        value="<?php echo e($item->login_nama); ?>">
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-6 col-md-6 col-lg-6">
                                                                <div class="form-group">
                                                                    <label for="login_username">
                                                                        <h6>Username</h6>
                                                                    </label>
                                                                    <input type="text" class="form-control"
                                                                        id="login_username"
                                                                        placeholder="Masukkan nama produk baru..."
                                                                        name="login_username"
                                                                        value="<?php echo e($item->login_username); ?>">
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="row">
                                                            <div class="col-sm-6 col-md-6 col-lg-6">
                                                                <div class="form-group">
                                                                    <label for="login_email">
                                                                        <h6>Email</h6>
                                                                    </label>
                                                                    <input type="text" class="form-control"
                                                                        id="login_email"
                                                                        placeholder="Masukkan nama produk baru..."
                                                                        name="login_email"
                                                                        value="<?php echo e($item->login_email); ?>">
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-6 col-md-6 col-lg-6">
                                                                <div class="form-group">
                                                                    <label for="login_telepon">
                                                                        <h6>No. HP / Telepon</h6>
                                                                    </label>
                                                                    <input type="number" class="form-control"
                                                                        id="login_telepon"
                                                                        placeholder="Masukkan nama produk baru..."
                                                                        name="login_telepon"
                                                                        value="<?php echo e($item->login_telepon); ?>">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">Batalkan</button>
                                                        <button type="submit" class="btn btn-danger">Ubah Data</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- END Modal Ubah -->

                                    <!-- Modal Hapus -->
                                    <div class="modal fade" id="modalhapus<?php echo e($item->id); ?>" tabindex="-1"
                                        role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Hapus User</h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <form action="<?php echo e(route('hapus-user', $item->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-body">
                                                        Apakah anda yakin ingin menghapus data user ini?
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">Batalkan</button>
                                                        <button type="submit" class="btn btn-danger">Hapus</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- END Modal Hapus -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('datatables')); ?>/datatables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-penjualan\resources\views/users/daftar-users.blade.php ENDPATH**/ ?>