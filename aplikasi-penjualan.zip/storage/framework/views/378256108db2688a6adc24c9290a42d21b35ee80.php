<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('datatables')); ?>/datatables.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('header-content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-md-6 col-lg-6">
                <h5 class="my-auto text-dark">Peramalan - Hasil Perhitungan Simple Moving Average</h5>
            </div>
            <div class="col-sm-6 col-md-6 col-lg-6 ml-auto">
                <button class="btn btn-md btn-primary d-flex my-auto ml-auto"
                    onclick="location.href = '<?php echo e(route('print-peramalan-penjualan')); ?>'">
                    Cetak Hasil Peramalan
                </button>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="card mb-3">
        <div class="card-body">
            <div class="container">
                <div class="row">
                    <div class="table-responsive">

                        <table id="" class="display table table-bordered" style="width:100%">
                            <thead class="thead-dark">
                                <tr>
                                    <th class="text-dark mr-auto">
                                        Total MAPE : <?php echo e(round($maper, 2)); ?>

                                    </th>
                                </tr>
                            </thead>
                        </table>

                        <table id="" class="display table table-bordered" style="width:100%">
                            <thead class="thead-dark">
                                <tr>
                                    <th scope="col" class="text-dark">No.</th>
                                    <th scope="col" class="text-dark">Nama Produk</th>
                                    <th scope="col" class="text-dark">Kategori</th>
                                    <th scope="col" class="text-dark">Ukuran</th>
                                    <th scope="col" class="text-dark">Jumlah Penjualan Aktual</th>
                                    <th scope="col" class="text-dark">Periode</th>
                                    <th scope="col" class="text-dark">Perhitungan Simple Moving Average</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-dark"><?php echo e($index + 1); ?></td>
                                        <td class="text-dark"><?php echo e($data->barang->barang_nama); ?></td>
                                        <td class="text-dark"><?php echo e($data->barang->barang_kategori); ?></td>
                                        <td class="text-dark"><?php echo e($data->barang->barang_ukuran); ?></td>
                                        <td class="text-dark"><?php echo e($data->penjualan_jumlah); ?></td>
                                        <td class="text-dark"><?php echo e(date('M', strtotime($data->penjualan_bulan_awal))); ?></td>
                                        <td class="text-dark"><?php echo e($hasilMovingAverage[$index]); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('datatables')); ?>/datatables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-penjualan\resources\views/dashboard/peramalan/hasil-peramalan.blade.php ENDPATH**/ ?>