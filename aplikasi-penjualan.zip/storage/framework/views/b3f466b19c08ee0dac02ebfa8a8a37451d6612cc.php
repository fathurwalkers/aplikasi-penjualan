<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('datatables')); ?>/datatables.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('header-content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-md-6 col-lg-6">
                <h5 class="my-auto text-dark">Penjualan - Daftar Penjualan</h5>
            </div>
            <div class="col-sm-6 col-md-6 col-lg-6">

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="card">
        <div class="card-body">
            <div class="container">

                <form action="<?php echo e(route('tambah-penjualan')); ?>" method="post">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="id_produk" id="id_produk">

                    <p class="text-dark">
                        Silahkan masukkan informasi Nama dan Jumlah stok barang baru.
                    </p>

                    <div class="row">
                        <div class="col-sm-10 col-md-10 col-lg-10">
                            <div class="form-group">
                                <label for="produk_kode">
                                    <h6>Produk</h6>
                                </label>
                                <input type="text" class="form-control" id="produk_kode" placeholder="..."
                                    name="produk_kode" disabled required>
                            </div>
                        </div>
                        <div class="col-sm-2 col-md-2 col-lg-2">
                            <label for="produk_kode">
                                <h6 style="color:#fff;">ke Tabel Produk</h6>
                            </label>
                            <a href="#daftarbarang" class="btn btn-info btn-md" width="100%">
                                Tabel Produk
                            </a>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6 col-md-6 col-lg-6">
                            <div class="form-group">
                                <label for="tahun">
                                    <h6>Tahun</h6>
                                </label>
                                <input type="number" class="form-control" id="tahun"
                                    placeholder="Masukkan periode tahun..." name="tahun" required>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-6">
                            <div class="form-group">
                                <label for="jumlah_penjualan">
                                    <h6>Jumlah Penjualan</h6>
                                </label>
                                <input type="number" class="form-control" id="jumlah_penjualan"
                                    placeholder="Masukkan jumlah penjualan..." name="jumlah_penjualan" required>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6 col-md-6 col-lg-6">
                            <div class="form-group">
                                <label for="bulan_awal">
                                    <h6>Bulan Awal</h6>
                                </label>
                                <select class="form-control" id="bulan_awal" name="bulan_awal" required>
                                    <?php $__currentLoopData = $array_bulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e(date('m', strtotime($item1))); ?>"><?php echo e($item1); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-6">
                            <div class="form-group">
                                <label for="bulan_akhir">
                                    <h6>Bulan Akhir</h6>
                                </label>
                                <select class="form-control" id="bulan_akhir" name="bulan_akhir" required>
                                    <?php $__currentLoopData = $array_bulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e(date('m', strtotime($item1))); ?>"><?php echo e($item1); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-12 col-md-12 col-lg-12 d-flex justify-content-end">
                            <button type="submit" class="btn btn-primary btn-md">
                                Tambah Penjualan
                            </button>
                        </div>
                    </div>

                </form>

            </div>
        </div>
    </div>

    <div class="card mb-3">
        <div class="card-body">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12">
                        <h5 class="my-auto text-dark">Daftar Penjualan</h5>
                    </div>
                </div>
                <hr />
                <div class="row">
                    <div class="table-responsive">
                        <table id="example" class="display table-bordered" style="width:100%">
                            <thead class="thead-dark">
                                <tr>
                                    <th>No.</th>
                                    <th>Nama Produk</th>
                                    <th>Kategori Produk</th>
                                    <th>Ukuran</th>
                                    <th>Bulan Awal</th>
                                    <th>Bulan Akhir</th>
                                    <th>Tahun</th>
                                    <th>Jumlah Penjualan</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center text-dark"><?php echo e($loop->iteration); ?></td>
                                        <td class="text-center text-dark"><?php echo e($item->barang->barang_nama); ?></td>
                                        <td class="text-center text-dark"><?php echo e($item->barang->barang_kategori); ?></td>
                                        <td class="text-center text-dark"><?php echo e($item->barang->barang_ukuran); ?></td>
                                        <td class="text-center text-dark">
                                            <?php echo e(date('d-M-Y', strtotime($item->penjualan_bulan_awal))); ?>

                                        </td>
                                        <td class="text-center text-dark">
                                            <?php echo e(date('d-M-Y', strtotime($item->penjualan_bulan_akhir))); ?>

                                        </td>
                                        <td class="text-center text-dark"><?php echo e($item->penjualan_tahun); ?></td>
                                        <td class="text-center text-dark"><?php echo e($item->penjualan_jumlah); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card mb-3" id="daftarbarang">
        <div class="card-body">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12">
                        <h5 class="my-auto text-dark">Daftar Barang</h5>
                    </div>
                </div>
                <hr />
                <div class="row">
                    <div class="table-responsive">
                        <table id="example2" class="display table-bordered" style="width:100%">
                            <thead class="thead-dark">
                                <tr>
                                    <th>No.</th>
                                    <th>Kode Produk</th>
                                    <th>Nama Produk</th>
                                    <th>Kategori Produk</th>
                                    <th>Ukuran Produk</th>
                                    <th>Kelola</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center text-dark"><?php echo e($loop->iteration); ?></td>
                                        <td class="text-center text-dark"><?php echo e($item->barang_kode); ?></td>
                                        <td class="text-center text-dark"><?php echo e($item->barang_nama); ?></td>
                                        <td class="text-center text-dark"><?php echo e($item->barang_kategori); ?></td>
                                        <td class="text-center text-dark"><?php echo e($item->barang_ukuran); ?></td>
                                        <td class="text-center text-dark">
                                            <button class="btn btn-sm btn-info mr-1" type="button"
                                                onclick="setproduk('<?php echo e($item->id); ?>','<?php echo e($item->barang_nama); ?>','<?php echo e($item->barang_kode); ?>')">
                                                Pilih
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('datatables')); ?>/datatables.min.js"></script>
    <script>
        function setproduk(id, nama, kode) {
            $('#produk_kode').val(kode);
            $('#id_produk').val(id);
        }

        $(document).ready(function() {
            $('#example').DataTable();
            $('#example2').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-penjualan\resources\views/dashboard/penjualan/daftar-penjualan.blade.php ENDPATH**/ ?>